    ,-~~-.___.            -----------------------------------    
   / |  '     \           	     Game Announcer
  (  )        0                  Created by Myst & cHip
   \_/-, ,----'                                        
      ====           //                    
     /  \-'~;    /~~~(O)
    /  __/~|   /       |           www.DarkBlizz.org
  =(  _____| (_________| -------------------------------------




             [[[[[[[[[[[[[[[[[[ DESCRIPTION ]]]]]]]]]]]]]]]]]] 
 .-"-._,-'_`-._,-'_`-._,-'_`-._,-'_`-,_,-'_`-,_,-'_`-,_,-'_`-,_,-'_`-,
 (  ,-'_,-".>-'_,-".>-'_,-".>-'_,-".>-'_,-~.=-'_,-~.=-'_,-~.=-'_,-~-} ;
  \ \.'_>-._`-<_>-._`-<_>-._`-<_>-._`-._=-._`-._=-._`-._=-._`-._~--. \
  /\ \/ ,-' `-._,-' `-._,-' `-._,-' `-._,-' `-._,-' `-._,-' `-._`./ \ \
 ( (`/ /                                                        `/ /.) )
  \ \ / \                                                       / / \ /
   \ ') )       The Bot will track any games, maps, hosts      ( (,\ \
  / \ / /       you want filtered and then display those games  \ / \ \
 ( (`/ /        in your channel right when they're created so    / /.) )
  \ \ / \       you don't have to stare at the gamelist         / / \ /
   \ ') )       yourself, waiting for games.                   ( (,\ \
  / \ / /                                                        \ / \ \
 ( (`/ /        Just sit back and chat away in your channel       / /.) )
  \ \ / \       while you wait for your filtered games!          / / \ /
   \ ') )                 				       ( (,\ \
  / \ y /                    				        \ y \ \
 ( ( y /                                                         y /.) )
  \ \ / \                                                       / / \ /
   \ ') )                                                      ( (,\ \
  / \ / /                                                       \ / \ \
 ( (`/ /                                                         / /.) )
  \ \ / \       _       _       _       _       _       _       / / \ /
   \ `.\ `-._,-'_`-._,-'_`-._,-'_`-._,-'_`-._,-'_`-._,-'_`-._,-'_/,\ \
  ( `. `,~-._`-=,~-._`-=,~-._`-=,~-._`-=,~-._`-=,~-._`-=,~-._`-=,' ,\ \
   `. `'_,-=_,-'_,-=_,-'_,-=_,-'_,-=_,-'_,-=_,-'_,-=_,-'_,-=_,-'_,"-' ;
     `-' `-._,-' `-._,-' `-._,-' `-._,-' `-._,-' `-._,-' `-._,-' `-.-'

Check out the HTML ReadMe also!!
------------------
 COMMANDS 
------------------

	        ***COMMANDS FOR FILTERING GAMES***  


+++++TRACK COMMAND+++++  (This command tells the bot what games to filter and display in channel)

	?track [game,map,host] [filter]

Examples:

	?track game snipe
This will track any game name with the word "snipe" in it.

	?track map bald locks
This will track any map with the word "bald locks" in it

	?track host Myst
This will track any game that "Myst" creates



+++++TIMEFILTER COMMAND+++++  (This command tells the bot only to display games if they're made within a certain timelimit)

	?timefilter [number], ?time [number] (Default filter time is 30secs)

Examples:

	?timefilter 11
This will only show filtered results created less than 11 secs ago


+++++SWITCH COMMAND+++++  (This command tells the bot to switch between either watching UMS, TopVBottom, or Melee games)

	?switch [UMS, TVB, MELEE] , ?watch [UMS, TVB, MELEE]

Example:
	
	?switch tvb
The bot will switch from whatever gametype it was previously checking to now checking TopVBottom games


+++++STOP COMMAND+++++  (This command tells the bot to stop checking the gamelist for any filtered games)

	?stop
Will stop the bot tracking games

+++++START COMMAND+++++  (This tells the bot to start checking again the gamelist for your filtered games)

	?start
Will start the tracking again


+++++CLEARALL COMMAND+++++  (This command will delete all filters you have inputed into the bot)

	?clearall, ?clear
Deletes all filters


+++++DELETEFILTER+++++  (This command will delete a specific filter)

	?deletefilter [filter], ?delete [filter]
Example: 
	?delete snipe
Deletes the filter "snipe" and the bot will stop looking for that filter


+++++FILTERCOUNT+++++  (This command will tell you how many filters the bot is currently checking)
	
	?filtercount
Shows how many filters there are


		***BOT COMMANDS***

+++++VER+++  (This command will output the version of the bot you have)

	?ver
Shows the version of the bot in channel



?add [user] [accesslevel]
ex) ?add Myst 80
Adds Myst with 80 access


For AccessLevels and more commands Checkout the HTML version of the ReadMe
Located in your Bot's folder.




|Support|
Visit www.DarkBlizz.org or irc.darkblizz.org #DarkBlizz
or
Clan Null @USEast

     ..:::::::..
    //////\\\\\\\
    |||||||||||||
    |||||||||||||
    |||||||||||||
HH  |||||||||||||   HH
HH==================HH
HH==================HH
HH  #############   HH
HH  #############   HH
HH   ###########    HH
HH    #########     HH
HH     #######      HH
HH      #####       HH
HH        ()        HH
\\         ()       //
  \\       ()     //
    \\      ()  //
      \\     (//
        \\  //)(
      ____\/___()
  ,#################....
 #####################  ```  Starcraft Game Announcer
~~~~~~~~~~~~~~~~~~~~~~~

